package com.nattakarn.Hotel_Diploma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelDiplomaApplicationTests {

	@Test
	void contextLoads() {
	}

}
