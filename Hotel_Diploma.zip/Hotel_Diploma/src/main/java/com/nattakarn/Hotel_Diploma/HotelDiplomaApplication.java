package com.nattakarn.Hotel_Diploma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelDiplomaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelDiplomaApplication.class, args);
	}

}
